### Asterix and the Bazaar

#### Members
1. Aditya Chaloo
2. Jenish Bajracharya

Simulate the network with `n` peers: `python3 main.py n`.  

Simulate the network with user-defined network `python3 test_main.py`. 
