# config.py
BUY_PROBABILITY = 1   # Probability that a buyer will continue buying after a successful purchase
SELLER_STOCK = 5     # Each seller starts with 5 items
MAX_TRANSACTIONS = 1000  # NUMBER OF TRANSACTIONS A BUYER CAN DO BEFORE IT SHUTSDOWN
TIMEOUT = 0.1  #S

